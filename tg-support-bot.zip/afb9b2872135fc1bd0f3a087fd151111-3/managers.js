const fs = require('fs');
const path = require('path');

const MANAGERS_FILE = path.join(__dirname, 'managers.json');

// Чтение списка менеджеров
function loadManagers() {
  if (fs.existsSync(MANAGERS_FILE)) {
    const data = fs.readFileSync(MANAGERS_FILE, 'utf8');
    return JSON.parse(data);
  }
  return {};
}

// Сохранение списка менеджеров
function saveManagers(data) {
  fs.writeFileSync(MANAGERS_FILE, JSON.stringify(data, null, 2), 'utf8');
}

// Удаление менеджера по ID
function removeManager(managerId) {
  const managers = loadManagers();
  if (managers[managerId]) {
    delete managers[managerId];
    saveManagers(managers);
    return true; // Успешно удалено
  }
  return false; // Менеджер не найден
}

module.exports = {
  loadManagers,
  saveManagers,
  removeManager,
};
