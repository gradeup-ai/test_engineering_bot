require('dotenv').config();
const {Telegraf} = require('telegraf');
const {loadManagers, saveManagers, removeManager} = require('./managers');

// === Конфигурация ===
const BOT_TOKEN = process.env.BOT_TOKEN;
const MANAGERS_CHAT_ID = Number(process.env.MANAGERS_CHAT_ID);

const bot = new Telegraf(BOT_TOKEN);

// Загружаем текущих менеджеров
const managerNames = loadManagers();

// === Вспомогательная функция для проверки рабочего времени (только выходные) ===
function isWorkingHours() {
  const now = new Date();
  const day = now.getDay(); // 0 = воскресенье, 1 = понедельник, ..., 6 = суббота

  // Рабочие дни: понедельник–пятница (1–5)
  return day >= 1 && day <= 5; // Возвращает true для будних дней
}

// Отправка медиафайлов с подписью
async function sendMedia(ctx, chatId, header) {
  const message = ctx.message;

  if (message.photo) {
    await bot.telegram.sendPhoto(chatId, message.photo.pop().file_id, {
      caption: `${header}\n${message.caption || ''}`,
      parse_mode: 'Markdown',
    });
  } else if (message.video) {
    await bot.telegram.sendVideo(chatId, message.video.file_id, {
      caption: `${header}\n${message.caption || ''}`,
      parse_mode: 'Markdown',
    });
  } else if (message.document) {
    await bot.telegram.sendDocument(chatId, message.document.file_id, {
      caption: `${header}\n${message.caption || ''}`,
      parse_mode: 'Markdown',
    });
  } else if (message.voice) {
    await bot.telegram.sendMessage(chatId, `${header}`, {
      parse_mode: 'Markdown',
    });
    await bot.telegram.sendVoice(chatId, message.voice.file_id);
  } else if (message.video_note) {
    await bot.telegram.sendMessage(chatId, `${header}`, {
      parse_mode: 'Markdown',
    });
    await bot.telegram.sendVideoNote(chatId, message.video_note.file_id);
  } else {
    await bot.telegram.sendMessage(
      chatId,
      `${header}\n${message.text || 'Неизвестный формат сообщения'}`,
      {
        parse_mode: 'Markdown',
      },
    );
  }
}

// === Команды ===
bot.start((ctx) => {
  const userName = ctx.from.first_name || 'Пользователь';
  const userId = ctx.from.id;
  ctx.reply(
    `👋 Привет, *${userName}*! Я бот поддержки. Напишите ваш вопрос, и я отправлю его нашим менеджерам!`,
    {parse_mode: 'Markdown'},
  );
  // Отправляем информацию о пользователе в чат менеджеров
  bot.telegram
    .sendMessage(
      MANAGERS_CHAT_ID,
      `🚨 Новый пользователь запустил бота!\n` +
        `Имя: *${userName}*\n` +
        `ID: \`${userId}\`\n` +
        `Профиль: [@${
          ctx.from.username || 'нет'
        }](tg://user?id=${userId})\n\n` +
        `Ответьте на это сообщение, чтобы написать пользователю.`,
      {parse_mode: 'Markdown'},
    )
    .catch((error) => {
      console.error('❌ Ошибка при отправке сообщения менеджерам:', error);
    });

  console.log(`✅ Пользователь ${userName} (ID: ${userId}) запустил бота.`);
});

// Установка имени менеджера
bot.command('addmanager', (ctx) => {
  const args = ctx.message.text.split(' ').slice(1); // Извлекаем аргументы команды
  if (args.length < 2) {
    return ctx.reply(
      '❌ Неверный формат команды. Используйте: `/addmanager <Telegram ID> <Новое имя>`',
      {parse_mode: 'Markdown'},
    );
  }

  const [managerId, ...nameParts] = args;
  const managerName = nameParts.join(' ');

  managerNames[managerId] = managerName;
  saveManagers(managerNames); // Сохраняем изменения в файл

  ctx.reply(
    `✅ Имя для менеджера с ID \`${managerId}\` установлено: ${managerName}`,
    {
      parse_mode: 'Markdown',
    },
  );
});

// Получение списка менеджеров
bot.command('managers', (ctx) => {
  if (Object.keys(managerNames).length === 0) {
    return ctx.reply('📋 Список менеджеров пуст.');
  }

  const list = Object.entries(managerNames)
    .map(([id, name]) => `• \`${id}\`: ${name}`)
    .join('\n');
  ctx.reply(`📋 Список менеджеров:\n${list}`, {parse_mode: 'Markdown'});
});

// Команда для удаления менеджера
bot.command('removemanager', (ctx) => {
  const args = ctx.message.text.split(' ').slice(1); // Аргументы команды
  if (args.length === 0) {
    return ctx.reply(
      '❌ Неверный формат команды. Используйте: `/removemanager <Telegram ID>`',
      {parse_mode: 'Markdown'},
    );
  }

  const managerId = args[0];
  if (removeManager(managerId)) {
    ctx.reply(`✅ Менеджер с ID \`${managerId}\` успешно удалён.`, {
      parse_mode: 'Markdown',
    });
  } else {
    ctx.reply(`⚠️ Менеджер с ID \`${managerId}\` не найден.`, {
      parse_mode: 'Markdown',
    });
  }
});

// === Обработка сообщений ===
bot.on('message', async (ctx) => {
  try {
    const {chat, message} = ctx;

    if (chat.type === 'private') {
      // Сообщения от клиентов
      const userId = ctx.from.id;
      const userName = ctx.from.username || ctx.from.first_name || 'Клиент';
      const header = `📩 *Сообщение от @${userName}* (ID: \`${userId}\`):`;

      await sendMedia(ctx, MANAGERS_CHAT_ID, header);
      if (!isWorkingHours()) {
        // В выходные дни
        await ctx.reply(
          `Ваше сообщение отправлено менеджерам. Мы обязательно ответим вам в рабочее время в понедельник.`,
        );
      } else {
        // В будние дни
        await ctx.reply(
          'Ваше сообщение отправлено менеджерам. Ожидайте ответа.',
        );
      }
    } else if (chat.id === MANAGERS_CHAT_ID && message.reply_to_message) {
      // Ответы менеджеров
      const replyMessage =
        message.reply_to_message.text || message.reply_to_message.caption;
      const match =
        replyMessage.match(/ID:\s(\d+)/) || replyMessage.match(/\(ID: (\d+)\)/);

      if (match) {
        const clientId = match[1];
        const managerId = ctx.from.id.toString();
        const managerName = managerNames[managerId] || ctx.from.first_name;
        const username = ctx.from.username ? ` (@${ctx.from.username})` : '';
        const header = `💬 *Ответ отправил ${managerName}${username}:*`;

        await sendMedia(ctx, clientId, header);
        await ctx.reply('✅ Ответ отправлен клиенту.');
      } else {
        await ctx.reply('⚠️ Не удалось определить клиента для ответа.');
      }
    }
  } catch (error) {
    console.error('❌ Ошибка при обработке сообщения:', error);
  }
});

// === Запуск бота ===
bot.launch();
console.log('🤖 Бот запущен и готов к работе...');

// === Обработка ошибок ===
process.on('SIGINT', () => {
  console.log('🛑 Бот остановлен (SIGINT)');
  bot.stop('SIGINT');
});
process.on('SIGTERM', () => {
  console.log('🛑 Бот остановлен (SIGTERM)');
  bot.stop('SIGTERM');
});
